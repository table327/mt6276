This archive contains several INF files (setup information files) which can
be used to install various drivers for MediaTek-based Android devices.

Most importantly the Preloader USB VCOM driver that is essential for getting
the SmartPhone Flash Tool (SPFT) to work.


Contents:

Android\android_winusb.inf
	Installs ADB (Android Debug Bridge, "USB-Debugging") driver for
	MediaTek's vendor ID (VID_0E8D).
	Optional. Your Android device might use a different vender ID anyway,
	so you should first try the vendor's ADB driver, if available.

CDC\cdc-acm.inf
	Installs VCOM (virtual serial port) driver.
	Required for the SPFT!


tetherxp.inf
	"RNDIS-over-USB host driver for Intenet Sharing".
	You probably don't need this.

wpdmtp.inf
	Media Transfer Protocol (MTP) driver for MediaTek's vendor ID.
	You probably don't need this on modern operating systems.



To install any of these INF files, first extract this ZIP archive.

Then, for Windows 8 and 10:
  Simply right-click any extracted INF file,
  and select "Install" in the appearing context menu.

For Windows 7:
  - Open the Windows Device Manager
  - In the "Action" menu, click "Add legacy hardware"
  - Click Next
  - Select "Install the hardware that I manually select from a list (Advanced)"
  - Click Next
  - In the list, select "Ports (COM & LPT)"
  - Click Next
  - Click "Have Disk..."
  - Browse for the INF file, e.g. cdc-acm.inf
  - Select the driver you want to install, e.g. "MediaTek PreLoader USB VCOM (Android)"
  - If a new device appears in the Device Manager with a yellow warning triangle
    and error code 10, just select it and delete it (delete key). But do NOT delete
    the driver software.

-Tzul
